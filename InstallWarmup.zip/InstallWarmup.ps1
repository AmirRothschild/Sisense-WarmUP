﻿$ServerURL = "http://localhost:8081"
$RecycleTime = "02:00"
$TaskTime = "2:05am"

# Sisense Warmup installer
$ScriptLocation = "C:\Scripts\Warmup.ps1"
New-Item -ItemType Directory -Path "C:\Scripts\" -ErrorAction SilentlyContinue
'$a = Invoke-WebRequest "{0}"' -f $ServerURL | Out-File $ScriptLocation

# Chaing IIS recycle settings
Import-Module WebAdministration
Set-ItemProperty "IIS:\AppPools\Sisense v4.0" -Name Recycling.periodicRestart.time -Value "00:00:00"
Set-ItemProperty -Path "IIS:\AppPools\Sisense v4.0" -Name Recycling.periodicRestart.schedule -Value @{value=$RecycleTime}



# Creating the scheduled task# The name of the scheduled task
$TaskName = "Sisense WarmUp"
# The description of the task
$TaskDescr = "Run a powershell script through a scheduled task to warmup IIS"
# The Task Action command
$TaskCommand = "c:\windows\system32\WindowsPowerShell\v1.0\powershell.exe"

# The Task Action command argument
$TaskArg = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file $ScriptLocation"
 
 
 $action = New-ScheduledTaskAction -Execute 'Powershell.exe' `
   -Argument "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file $ScriptLocation"

$trigger =  New-ScheduledTaskTrigger -Daily -At $TaskTime

Register-ScheduledTask -Action $action -Trigger $trigger -TaskName $TaskName -Description $TaskDescr